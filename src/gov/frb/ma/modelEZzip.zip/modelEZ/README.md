modelEZ
=======

original AMA(AIM) preprocessor
